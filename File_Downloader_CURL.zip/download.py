import requests

print("Enter The URL :")
URL = input()
print("Enter The File Name")
NAME = input()

open(NAME, "wb").write(requests.get(URL).content)

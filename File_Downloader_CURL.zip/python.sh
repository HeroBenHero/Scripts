mkdir Torrent
mv download.py Torrent
python Torrent\download.py
./rclone copy Torrent\* Shared:Torrent --progress --config=rclone.conf